export const enum CinestationEvent {
    EDITOR_CHANGED  = "cinestation-editor-changed",
    COMPOSER_CHANGED = "cinestation-composer-changed",
    LENS_CHANGED = "cinestation-lens-changed",
}