declare const CC_EDITOR: boolean;
declare const cc_JSB: boolean;
declare const cce: any;